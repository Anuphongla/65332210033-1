<?php
// เริ่ม session หรือเปิด session ที่มีอยู่
session_start();

// เรียกไฟล์ server.php ซึ่งอาจจะมีการกำหนดตัวแปรหรือฟังก์ชันอื่น ๆ
include('../css/server.php');

// เชื่อมต่อกับฐานข้อมูล MySQL
$conn = new mysqli('localhost', 'root', '', 'register_db');

// ตรวจสอบว่ามีพารามิเตอร์ "id" ใน URL
if (isset($_GET["id"])) {
    $post_id = $_GET["id"];

    // ส่งคำสั่ง SQL เพื่อดึงโพสต์ที่มี id ตรงกับที่ระบุ
    $sql = "SELECT * FROM posts WHERE id = $post_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // หากพบโพสต์
        $post = $result->fetch_assoc();
        $post_title = $post["title"];
        $post_content = $post["content"];

        // ส่งคำสั่ง SQL เพื่อดึงคอมเมนต์ที่เกี่ยวข้องกับโพสต์นี้
        $comment_sql = "SELECT * FROM comments WHERE post_id = $post_id";
        $comment_result = $conn->query($comment_sql);
    } else {
        // หากไม่พบโพสต์
        echo "ไม่พบโพสต์ที่คุณต้องการ";
    }
} else {
    // หากไม่มีพารามิเตอร์ "id" ใน URL
    echo "ไม่มีรหัสโพสต์ที่ระบุ";
}

// ปิดการเชื่อมต่อกับฐานข้อมูล
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $post_title; ?></title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>


        .bodypost {
            text-align: left; 
            margin-left: 50px;
            background-color: rgba(255, 255, 255, 0.6); /* สีขาวขุ่น */
            backdrop-filter: blur(8px); /* เอฟเฟกต์เบลอ */
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            max-width: 1750px ; /* เพิ่มบรรทัดนี้เพื่อกำหนดความกว้างสูงสุด */
            
        }
        body {
            background-image: url('https://cx.lnwfile.com/_/cx/_raw/aj/6n/ro.jpg');
            background-size: cover;
            background-attachment: fixed;
            backdrop-filter: blur(4px);
        }

        p {
            margin-left: 10px;
        } 
        p1 {
            margin-left: 15px;
        }
        .right-align {
            text-align: right; 
            margin-right: 30px;
        }
        h3 {
        font-size: 30px;
        color: green;
        text-align: left; /* กำหนดให้เนื้อหาของ <h2> ชิดซ้าย */
        margin-left: 30px; /* เพิ่มระยะข้างขวา */
        }


            /* CSS สำหรับปุ่ม Logout */
        #logout-button {
            background-color: red; /* สีแดง */
            color: white; /* สีของตัวอักษร */
            border: none; /* ลบเส้นขอบ */
            padding: 10px 20px; /* ขนาดของปุ่ม */
            border-radius: 5px; /* มุมขอบโค้ง */
            cursor: pointer; /* เมื่อนำเมาส์มาวางบนปุ่ม */
            text-decoration: none; /* ลบขีดเส้นใต้ข้อความ */
            text-align: left;
            margin-left: 30px;
            font-size: 15px;
        }

        #logout-button:hover {
            background-color: darkred; /* สีแดงเข้มเมื่อนำเมาส์มาวางบนปุ่ม */
        }

        form {
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
        }

        /* CSS สำหรับเนื้อหาของแบบฟอร์มโพสต์ใหม่ */
        form label,
        form input[type="text"],
        form textarea {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        form input[type="submit"] {
            background-color: blue;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 15px;
        }


      


    </style>
</head>
<body>
    <!-- เริ่มส่วนของเนื้อหา HTML -->

    <!-- ส่วนของเนื้อหาด้านบน -->
    <div class="right-align">
        <!-- ลิงก์ที่คุณต้องการแสดงด้านขวา -->
        <p style="color: white; font-size: 25px;"> Back to <a href="http://localhost/SQL_PROJECT/test_post/" style="color: yellowgreen;">กระทู้</a> </p>
    </div>

    <!-- ส่วนหัวของหน้า -->
    <h1 style="font-size: 50px; color: #FFD700; text-transform: uppercase; text-align: center;" >comment</h1><br>

    <!-- เนื้อหาหลัก -->
    <div class="bodypost">
        <p style="font-size: 26px; color: purple;"><strong style="font-size: 30px;">หัวข้อ:</strong> <?php echo $post_title; ?></p>
        <p style="font-size: 20px; color: black;"> <strong style="font-size: 20px; margin-left: 30px;">ข้อความ:</strong> <?php  echo $post_content; ?></p>
        <h2 style="font-size: 20px; color: blue;">คอมเมนต์</h2>

        <?php
        if ($comment_result->num_rows > 0) {
            // หากมีคอมเมนต์
            while ($comment = $comment_result->fetch_assoc()) {
                echo '<p><span style="color: red; font-weight: bold;">ชื่อ:</span> ' . $comment["name"] . '<p/>';
                echo '<p1><span style="color: blue; font-weight: bold;">ข้อความ:</span> ' . $comment["content"] . '</p1>';
            }
        } else {
            // หากไม่มีคอมเมนต์
            echo "ไม่มีคอมเมนต์ในโพสต์นี้";
        }
        ?>

        <br><br><h3>เพิ่มคอมเมนต์ใหม่</h3>
    </div>
    <br><br>

    <?php
    include('../css/server.php');

    // ตรวจสอบว่าผู้ใช้ล็อกอินหรือยัง
    if (isset($_SESSION['username'])) {
        // ผู้ใช้ล็อกอินแล้ว แสดงแบบฟอร์มสำหรับโพสต์คอมเมนต์ใหม่
        echo '
        <form action="add_comment.php" method="post">
            <input type="hidden" name="post_id" value="' . (isset($post_id) ? $post_id : '') . '">
            <label for="name">ชื่อ:</label>
            <input type="text" name="name" id="name">
            <br>
            <label for="comment">คอมเมนต์:</label>
            <textarea name="comment" id="comment" rows="4" cols="50"></textarea>
            <br>
            <input type="submit" value="ส่งคอมเมนต์">
        </form>
        ';
    } else {
        // ผู้ใช้ยังไม่ได้ล็อกอิน แสดงข้อความหรือลิงก์ไปยังหน้าล็อกอิน
        echo '<p style="color: white;">โปรดล็อกอินเพื่อโพสต์ข้อความใหม่: <a href="http://localhost/SQL_PROJECT/css/login.php">เข้าสู่ระบบ</a></p>';
    }
    ?>

    <!-- ส่วนสุดท้ายของหน้า HTML -->
    <?php if (isset($_SESSION['username'])) : ?>
        <p style="color: white;">Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
        <button id="logout-button"><a href="logout.php" style="color: white;">Logout</a></button>
    <?php endif ?>
</body>
</html>
