<?php  
session_start();

?>

<!DOCTYPE html>
<html>
<head>
    
    <title>โพสต์และคอมเมนต์</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>

        .right-align {
            text-align: right; 
            margin-right: 30px;
        }   
        .bodypost {
            text-align: left; 
            margin-left: 50px;
            background-color: rgba(255, 255, 255, 0.6); /* สีขาวขุ่น */
            backdrop-filter: blur(8px); /* เอฟเฟกต์เบลอ */
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            max-width: 1750px ; /* เพิ่มบรรทัดนี้เพื่อกำหนดความกว้างสูงสุด */
            
        }


        h3 {
            margin-left: 10px;

        
         }

        p {
            margin-left: 25px;
        }

        #logout-button {
            background-color: red; /* สีแดง */
            color: white; /* สีของตัวอักษร */
            border: none; /* ลบเส้นขอบ */
            padding: 10px 20px; /* ขนาดของปุ่ม */
            border-radius: 5px; /* มุมขอบโค้ง */
            cursor: pointer; /* เมื่อนำเมาส์มาวางบนปุ่ม */
            text-decoration: none; /* ลบขีดเส้นใต้ข้อความ */
            text-align: left;
            margin-left: 30px;
            font-size: 15px;
        }

        #logout-button:hover {
            background-color: darkred; /* สีแดงเข้มเมื่อนำเมาส์มาวางบนปุ่ม */
        }
        body {
            background-image: url('https://cx.lnwfile.com/_/cx/_raw/aj/6n/ro.jpg');
            background-size: cover;
            background-blend-mode: 70% ; /* หรือคุณสามารถใช้ backdrop-filter: blur(10px); แทนได้ */
            background-attachment: fixed;
            background-position: center;
        }

        form {
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
        }

        /* CSS สำหรับเนื้อหาของแบบฟอร์มโพสต์ใหม่ */
        form label,
        form input[type="text"],
        form textarea {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        form input[type="submit"] {
            background-color: blue;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 15px;
        }
        h1 {
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            background: linear-gradient(45deg, #FFD700, #FFFF00);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-size: 60px;
            
        }
         

    </style>
</head>
<body>

    <div class="right-align">
        <!-- ลิงก์ที่คุณต้องการแสดงด้านขวา -->
        <p style="color: white; font-size: 25px;"> Go to <a href="http://localhost/SQL_PROJECT/css/indexz.php" style="color: yellowgreen;">Homepage </a> </p>
    </div>



    <center>
    <h1>กระทู้</h1>
    </center>




    <!-- แสดงโพสต์ -->

    <div class="bodypost ">

    <h2 style="font-size: 35px; text-align: left; margin-left: 30px; color: black;">โพสต์</h2>
    

    <?php
    // เชื่อมต่อกับฐานข้อมูล
    $conn = new mysqli('localhost', 'root', '', 'register_db');

    // ตรวจสอบการเชื่อมต่อ
    if ($conn->connect_error) {
        die("การเชื่อมต่อฐานข้อมูลล้มเหลว: " . $conn->connect_error);
    }

    // ส่งคำสั่ง SQL เพื่อดึงโพสต์
    $sql = "SELECT * FROM posts";
    $result = $conn->query($sql);

    // แสดงโพสต์

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<h3 style="font-size: 24px; color: purple;">หัวข้อ: ' . $row["title"] . '</h3>';
            echo '<p style="font-size: 16px; color: black;">ข้อความ: ' . $row["content"] . '</p>';
            // แสดงลิงค์ไปยังหน้าโพสต์แต่ละโพสต์
            echo '<a href="post.php?id=' . $row["id"] . '">ดูรายละเอียด</a>';

        }
        

    } else {
        echo "ไม่มีโพสต์";
    }
    

    // ปิดการเชื่อมต่อ
    $conn->close();
    ?>

    <!-- แบบฟอร์มสำหรับโพสต์ใหม่ -->
    <h2 style="font-size: 35px; text-align: left; margin-left: 30px; color: black;">โพสต์ใหม่</h2>

    </div>
    

<?php
    include('../css/server.php');


    
    if (isset($_SESSION['username'])) {
        // ผู้ใช้ล็อกอินแล้ว แสดงแบบฟอร์มสำหรับโพสต์ใหม่
        echo '
        <form action="add_post.php" method="post">
            <label for="title">หัวข้อ:</label>
            <input type="text" name="title" id="title">
            <br>
            <label for="content">เนื้อหา:</label>
            <textarea name="content" id="content" rows="4" cols="50"></textarea>
            <br>
            <!-- เพิ่ม input hidden เพื่อส่ง username ไปกับโพสต์ -->
            <input type="hidden" name="userna   me" value="' . $_SESSION['username'] . '">
            <input type="submit" value="โพสต์">
        </form>';
    }
    else
    {
        // ผู้ใช้ยังไม่ได้ล็อกอิน แสดงข้อความหรือลิงก์ไปยังหน้าล็อกอิน
        echo '<p style="color: white;">โปรดล็อกอินเพื่อโพสต์ข้อความใหม่: <a href="http://localhost/SQL_PROJECT/css/login.php" >เข้าสู่ระบบ</a></p>';
    }
?>

<?php if (isset($_SESSION['username'])) : ?>
    <p style="color: white;">Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    <button id="logout-button"><a href="logout.php" style="color: white;">Logout</a></button>
<?php endif ?>
        

</body>
</html>
