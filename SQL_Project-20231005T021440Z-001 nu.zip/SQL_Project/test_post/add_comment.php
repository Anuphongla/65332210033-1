<?php
// ตรวจสอบว่ามีคำขอเป็น POST หรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // เชื่อมต่อกับฐานข้อมูล MySQL
    $conn = new mysqli('localhost', 'root', '', 'register_db');

    // ตรวจสอบการเชื่อมต่อ
    if ($conn->connect_error) {
        die("การเชื่อมต่อฐานข้อมูลล้มเหลว: " . $conn->connect_error);
    }

    // รับข้อมูลจากฟอร์ม
    $post_id = $_POST["post_id"];
    $name = $_POST["name"];
    $comment = $_POST["comment"];

    // สร้างคำสั่ง SQL เพื่อเพิ่มคอมเมนต์ใหม่
    $sql = "INSERT INTO comments (post_id, name, content) VALUES ('$post_id', '$name', '$comment')";

    if ($conn->query($sql) === TRUE) {
        // หากคอมเมนต์ถูกเพิ่มเรียบร้อย
        header("Location: post.php?id=$post_id");
        exit(); // หยุดการดำเนินการต่อ
    } else {
        // หากมีข้อผิดพลาดในการเพิ่มคอมเมนต์
        echo "ข้อผิดพลาด: " . $conn->error;
    }

    // ปิดการเชื่อมต่อกับฐานข้อมูล
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>เพิ่มคอมเมนต์</title>
</head>
<body>
    
    <h1>เพิ่มคอมเมนต์</h1>
    
    <form action="add_comment.php" method="post">
        <!-- ใส่ฟิลด์ที่ใช้ส่งข้อมูล post_id ในรูปแบบ hidden เพื่อส่งค่า id ไปกับคอมเมนต์ -->
        <input type="hidden" name="post_id" value="<?php echo isset($_GET['id']) ? $_GET['id'] : ''; ?>">

        <label for="name">ชื่อ:</label>
        <input type="text" name="name" id="name">
        <br>
        <label for="comment">คอมเมนต์:</label>
        <textarea name="comment" id="comment" rows="4" cols="50"></textarea>
        <br>
        <input type="submit" value="ส่งคอมเมนต์">
    </form>

</body>
</html>
