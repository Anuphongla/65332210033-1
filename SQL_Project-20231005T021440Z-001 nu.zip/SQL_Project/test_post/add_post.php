<?php
// เริ่ม session หรือเปิด session ที่มีอยู่
session_start();

// เรียกไฟล์ server.php ซึ่งอาจจะมีการกำหนดตัวแปรหรือฟังก์ชันอื่น ๆ
include('../css/server.php');

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือยัง
if (isset($_SESSION['username'])) {
    // ผู้ใช้ล็อกอินแล้ว แสดงแบบฟอร์มสำหรับโพสต์ใหม่

    // ... (แบบฟอร์มของคุณ)

} else {
    // ผู้ใช้ยังไม่ได้ล็อกอิน ให้ส่งผู้ใช้กลับไปที่หน้าล็อกอิน
    header("Location: http://localhost/SQL_PROJECT/css/login.php");
    exit();
}

// ตรวจสอบว่ามีคำขอเป็น POST หรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // เชื่อมต่อกับฐานข้อมูล MySQL
    $conn = new mysqli('localhost', 'root', '', 'register_db');

    // ตรวจสอบการเชื่อมต่อ
    if ($conn->connect_error) {
        die("การเชื่อมต่อฐานข้อมูลล้มเหลว: " . $conn->connect_error);
    }

    // รับข้อมูลจากฟอร์ม
    $title = $_POST["title"];
    $content = $_POST["content"];

    // สร้างคำสั่ง SQL เพื่อเพิ่มโพสต์ใหม่
    $sql = "INSERT INTO posts (title, content) VALUES ('$title', '$content')";

    if ($conn->query($sql) === TRUE) {
        // หากโพสต์ถูกเพิ่มเรียบร้อย
        header("Location: index.php");
        exit(); // หยุดการดำเนินการต่อ
    } else {
        // หากมีข้อผิดพลาดในการเพิ่มโพสต์
        echo "ข้อผิดพลาด: " . $conn->error;
    }

    // ปิดการเชื่อมต่อกับฐานข้อมูล
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>โพสต์ใหม่</title>
</head>
<body>
    <h1>โพสต์ใหม่</h1>
    <form action="add_post.php" method="post">
        <label for="title">หัวข้อ:</label>
        <input type="text" name="title" id="title">
        <br>
        <label for="content">เนื้อหา:</label>
        <textarea name="content" id="content" rows="4" cols="50"></textarea>
        <br>
        <input type="submit" value="โพสต์">
    </form>
</body>
</html>
