<?php
session_start(); // เริ่มเซสชัน

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION["user_id"]; // รหัสผู้ใช้จากเซสชัน
    $content = $_POST["post_content"];

    // เพิ่มโพสต์ลงในฐานข้อมูล
    $sql = "INSERT INTO posts (user_id, content) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $content);
    $stmt->execute();
    $stmt->close();
}

header("Location: index.php"); // ย้ายกลับไปที่หน้าแรกหลังจากโพสต์
?>
