

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>วันลอยกระทง 2563 (Loy Krathong Festival)</title>
    <link rel="stylesheet" href="style.css">
    <style>

        .right-align {
            text-align: right; 
            margin-right: 30px;
            margin-top: 15px;
        }
        body {
            background-image: url('https://cx.lnwfile.com/_/cx/_raw/aj/6n/ro.jpg');
            background-size: cover;
            background-attachment: fixed;
            backdrop-filter: blur(4px);
            
        }
        body, h1, h2, h3, p, a {
            margin: 0;
            padding: 0;
        }
        .homeheader {
            text-align: center;
            padding: 20px 0;
        }

        .newheader {
            text-align: left;
            padding: 5px 5px 5px 5px;
            font-size: 40px;
            color: #00008B; /* สีน้ำเงินเข้ม */
            text-decoration: underline; /* เพิ่มเส้นใต้ */
        }

        


        h2 {
            font-family: "AungsananeW", sans-serif;
            /* ส่วนอื่นๆของ CSS ที่คุณมีอาจต้องเพิ่มเติมตามความต้องการ */
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            background: linear-gradient(45deg, #FFD700, #FFFF00);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        /* กรอบเนื้อหาสีใสเบลอ 70% */
        .content {
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            padding: 50px;
            margin: 50px auto;
            max-width: 1500px;
        }

        /* เนื้อหาของหน้าเว็บ */
        .main-content {
            z-index: 1;
            position: relative;
            color: #333;
        }

        /* CSS เพิ่มเติมที่จัดหน้าเนื้อหา */
        .main-content {
            display: flex;
            flex-direction: column;
            align-items: center; /* จัดให้อยู่ตรงกลางแนวนอน */
            text-align: center; /* จัดให้อยู่ตรงกลางแนวตั้ง */
        }

        /* CSS สำหรับรูปภาพ */
        .main-content img {
            max-width: 100%; /* รูปภาพจะไม่ใหญ่เกินไป */
            height: auto;
            margin: 10px 0; /* เพิ่มระยะห่างรอบรูปภาพ */
        }


        .video-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px 0;
        }

        .video-container iframe {
            max-width: 100%;
            max-height: 100%;
        }


    </style>
</head>
<body>


    <div class="right-align">
        <!-- ลิงก์ที่คุณต้องการแสดงด้านขวา -->
            <p style="color: white; font-size: 25px;"> Go to <a href="http://localhost/SQL_PROJECT/test_post/" style="color: yellowgreen;">กระทู้</a> </p>
    </div>


        <div class="homeheader">
            <h2>วันลอยกระทง</h2>
        </div>
    

        <div class="homecontent">
            <!--- notification messange --->
            <?php if (isset($_SESSION['success'])) : ?>
                    <div class="success">
                            <h3>
                                        <?php  
                                            echo $_SESSION['success'];
                                            unset($_SESSION['success']);
                                        ?>
                            </h3>
                    </div>

              <?php endif ?>
           

                 <!-- loged in user information-->
                <?php if (isset($_SESSION['username'])) : ?>
                    <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
                    <p><a href="index.php?logout='1'" style="color: red;">Logout</a></p>

                <?php endif ?>

                <div>


                        <!-- สร้างฟอร์มสำหรับปุ่มหรือลิงก์ไปหน้าถัดไป -->
                            
                </div>

         </div>
       
    </div>


    <div class="content">
        
                    <div class="newheader">
                             <h3>ประวัติความเป็นมาของวันลอยกระทง</h3>
                    </div>
                    <br>
        
        <div class="main-content">
            
            <h1>วันลอยกระทง 2563 (Loy Krathong Festival)</h1>

            <div class="video-container">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/3PEsEhoX9fE" frameborder="0" allowfullscreen></iframe>
            </div>
                        

            <br><img src="https://mthai.com/app/uploads/2021/09/loykrathong-mthai-2021.jpg" style="height: 300px; width: 500px;" alt="รูปภาพ Loy Krathong"></br>


            <p>
                ลอยกระทง เป็นพิธีอย่างหนึ่งที่มักจะทำกันในคืนวันเพ็ญ เดือน 12 หรือวันขึ้น 15 ค่ำเดือน 12 อันเป็นวันพระจันทร์เต็มดวง และเป็นช่วงที่น้ำหลากเต็มตลิ่ง โดยจะมีการนำดอกไม้ ธูป เทียนหรือสิ่งของใส่ลงในสิ่งประดิษฐ์รูปต่างๆ ที่ไม่จมน้ำ เช่น กระทง เรือ แพ ดอกบัว ฯลฯ แล้วนำไปลอยตามลำน้ำ โดยมีวัตถุประสงค์ และความเชื่อต่างๆ กัน ในปีนี้ วันลอยกระทง ตรงกับ วันเสาร์ที่ 31 ตุลาคม 2563
            </p>
            
            <p>
                การลอยกระทง เป็นประเพณีที่มีมาแต่โบราณ แต่ไม่ปรากฏหลักฐานแน่ชัดว่า ปฏิบัติกันมาแต่เมื่อไร เพียงแต่ท้องถิ่นแต่ละแห่ง ก็จะมีจุดประสงค์และความเชื่อในการลอยกระทงแตกต่างกันไป เช่น ในเรื่องเกี่ยวกับพระพุทธศาสนา ก็จะเป็นการบูชาพระเกศแก้วจุฬามณีบนสวรรค์ชั้นดาวดึงส์, เป็นบูชารอยพระพุทธบาท ณ หาดทรายริมฝั่งแม่น้ำนัมมทา ซึ่งปัจจุบันคือแม่น้ำเนรพุททาในอินเดีย หรือต้อนรับพระพุทธเจ้า ในวันเสด็จกลับจากเทวโลก เมื่อครั้งไปโปรดพระพุทธมารดา
            </p>

            <br><img src="https://teen.mthai.com/app/uploads/wp-post-thumbnail/SjcF2X.jpg" style="height: 300px; width: 500px;"  alt="รูปภาพ Loy Krathong"></br>

            <p>
                ลอยกระทง ก็ยังมีวัตถุประสงค์ เพื่อบูชาพระอุปคุตเถระที่บำเพ็ญบริกรรมคาถาในท้องทะเลลึก หรือสะดือทะเล บางแห่งก็ลอยกระทง เพื่อบูชาเทพเจ้าตามความเชื่อของตน บางแห่งก็เพื่อแสดงความขอบคุณพระแม่คงคา ซึ่งเป็นแหล่งน้ำให้มนุษย์ได้ใช้ประโยชน์ต่างๆ รวมทั้งขอขมาที่ได้ทิ้งสิ่งปฏิกูลลงไป ส่วนบางท้องที่ ก็จะทำเพื่อระลึกถึงบรรพบุรุษที่ล่วงลับ หรือเพื่อสะเดาะเคราะห์ ลอยทุกข์โศกโรคภัยต่างๆ และส่วนใหญ่ก็จะอธิษฐานขอสิ่งที่ตนปรารถนาไปด้วย
            </p>

            <br><img src="https://www.thaiticketmajor.com/variety/img_news/title/original1/0259/12259/title_ttmnews_12259-20191021175813.jpg" style="height: 300px; width: 500px;" alt="รูปภาพ Loy Krathong"></br>
            <p>
                พระยาอนุมานราชธน ได้สันนิษฐานว่า ต้นเหตุแห่งการลอยกระทง อาจมีมูลฐานเป็นไปได้ว่า การลอยกระทงเป็นคติของชนชาติที่ประกอบกสิกรรม ซึ่งต้องอาศัยน้ำเป็นสำคัญ เมื่อพืชพันธุ์ธัญชาติงอกงามดี และเป็นเวลาที่น้ำเจิ่งนองพอดี ก็ทำกระทงลอยไปตามกระแสน้ำไหล เพื่อขอบคุณแม่คงคา หรือเทพเจ้าที่ประทานน้ำมาให้ความอุดมสมบูรณ์ เหตุนี้ จึงได้ลอยกระทงในฤดูกาลน้ำมาก และเมื่อเสร็จแล้ว จึงเล่นรื่นเริงด้วยความยินดี เท่ากับเป็นการสมโภชการงานที่ได้กระทำว่า ได้ลุล่วงและรอดมาจนเห็นผลแล้ว ท่านว่าการที่ชาวบ้านบอกว่า การลอยกระทงเป็นการขอขมาลาโทษ และขอบคุณต่อแม่คงคา ก็คงมีเค้าในทำนองเดียวกับการที่ชาติต่างๆ แต่ดึกดำบรรพ์ได้แสดงความยินดี ที่พืชผลเก็บเกี่ยวได้ จึงได้นำผลผลิตแรกที่ได้ ไปบูชาเทพเจ้าที่ตนนับถือ เพื่อขอบคุณที่บันดาลให้การเพาะปลูกของตนได้ผลดี รวมทั้งเลี้ยงดูผีที่อดอยาก และการเซ่นสรวงบรรพบุรุษที่ล่วงลับ เสร็จแล้วก็มีการสมโภชเลี้ยงดูกันเอง
            </p>

            <br><img src="https://medias.thansettakij.com/uploads/images/contents/w1024/2022/11/OlVZsjvbcnKavn9lWXLa.webp" style="height: 300px; width: 500px;"  alt="รูปภาพ Loy Krathong"></br>


            <p>
                ต่อมาเมื่อมนุษย์มีความเจริญแล้ว การวิตกทุกข์ร้อน เรื่องเพาะปลูกว่าจะไม่ได้ผลก็น้อยลงไป แต่ก็ยังทำการบวงสรวง ตามที่เคยทำมาจนเป็นประเพณี เพียงแต่ต่างก็แก้ให้เข้ากับคติลัทธิทางศาสนาที่ตนนับถือ เช่น มีการทำบุญสุนทานเพิ่มขึ้นในทางพุทธศาสนา เป็นต้น แต่ที่สุด ก็คงเหลือแต่การเล่นสนุกสนานรื่นเริงกันเป็นส่วนใหญ่ อย่างไรก็ดี ด้วยเหตุดังกล่าวข้างต้น การลอยกระทงจึงมีอยู่ในชาติต่างๆทั่วไป และการที่ไปลอยน้ำ ก็คงเป็นความรู้สึกทางจิตวิทยา ที่มนุษย์โดยธรรมดา มักจะเอาอะไรทิ้งไปในน้ำให้มันลอยไป
            </p>
        </div>
    </div>



</body>
</html>