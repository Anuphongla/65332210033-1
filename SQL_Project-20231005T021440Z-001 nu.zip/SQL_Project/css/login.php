<?php  
    include('server.php'); 
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
    <style>

        .right-align {
            text-align: right; 
            margin-right: 30px;
            margin-top: 15px;
        }
        body {
            background-image: url('https://cx.lnwfile.com/_/cx/_raw/aj/6n/ro.jpg');
            background-size: cover;
            background-blend-mode: 70% ; /* หรือคุณสามารถใช้ backdrop-filter: blur(10px); แทนได้ */
            background-attachment: fixed;
            background-position: center;
        }


    </style>
</head>
<body>


    <div class="right-align">
        <!-- ลิงก์ที่คุณต้องการแสดงด้านขวา -->
            <p style="color: white; font-size: 25px;"> Go to <a href="http://localhost/SQL_PROJECT/css/indexz.php" style="color: yellowgreen;">Homepage</a> </p>
    </div>



    <div class="header">
        <h2>Login</h2>

    </div>

    <form action="login_db.php" method="post">
        <?php if (isset($_SESSION['error'])) : ?>
            <div class="error">
                <h3>
                    <?php  
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </h3>
            </div>
        <?php endif ?>

            <div class="intput-group">
                <label for="username">Username</label>
                <input type="text" name="username">

            </div>
            <div class="intput-group">
                <label for="password">Password</label>
                <input type="password" name="password">
            </div>
             <div class="intput-group">
                <button type="submit" name="login_user" class="btn">Login</button>
        </div>
        <p> Not yet a member ? <a href="register.php">Sign Up</a> </p>
    </form>

</body>
</html>